const s="/intranet/assets/logo-unsm-c77fdc07.png",o="/intranet/assets/logo-fcs-b9c7ecb4.png";export{o as a,s as l};
